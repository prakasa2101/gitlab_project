const handler = async (event) => {
  try {
    if (event.triggerSource === "CustomMessage_SignUp" || event.triggerSource === 'CustomMessage_ResendCode') {
      const verificationLink = `http://sequel-twiist-test-account-be-lb-658595434.us-east-1.elb.amazonaws.com/accounts/verify?code=${event.request.codeParameter}&user=${event.userName}`;
 
      const emailMessage = `
              <p>Thank you for signing up with Sequel! To complete your registration, please click on the following link to verify your email address:</p>
              <p><a href='${verificationLink}' target='_blank'>Click here to verify your email</a></p>
              <p>If you did not sign up for Sequel, please ignore this email.</p>
              <br>
              <p>Best regards,</p>
                      Sequel Team
      `;
 
      event.response.emailMessage = emailMessage;
      event.response.emailSubject = "Verify your Email for Sequel";
      
    }
    if (event.triggerSource === "CustomMessage_ForgotPassword") {
      const userEmail = event.request.userAttributes.email;
      const firstname = event.request.userAttributes.given_name || "";
      const lastname = event.request.userAttributes.family_name || "";
      const resetLink = `http://sequel-twiist-test-account-fe-lb-546273772.us-east-1.elb.amazonaws.com/reset-password?code=${event.request.codeParameter}&user=${event.userName}&email=${userEmail}`;
 
      const emailMessage = `
            <p>We received a request to reset your password for Sequel. If you initiated this request, please click on the following link to reset your password:</p>
            <p><a href='${resetLink}' target='_blank'>Reset Password</a></p>
            <p>If you did not request a password reset, please ignore this email.</p>
            <br>
            <p>Best regards,</p>
                    Sequel Team
      `;
 
      event.response.emailMessage = emailMessage;
      event.response.emailSubject = "Password Reset Request for Sequel";
    }
 
    // Additional scenario handling for errors
    if (event.triggerSource === "TokenGeneration_Authentication") {
      // Check if the error is due to unverified email
      if (
        event.request.challengeName === "CUSTOM_CHALLENGE" &&
        event.request.failAuthentication === true
      ) {
        throw new Error(
          "Email not verified. Please verify your email before accessing the account."
        );
      }
 
      // Check if the error is due to incorrect password
      if (
        event.request.challengeName === "PASSWORD_VERIFIER" &&
        event.request.failAuthentication === true
      ) {
        throw new Error(
          "Incorrect password. Please enter the correct password."
        );
      }
 
      // Check if the error is due to non-existent user account
      if (event.request.userNotFound === true) {
        throw new Error("No account found with this email address.");
      }
      
    }
    
    return event;
  } catch (error) {
    // Return error message
   // throw new Error(error.message);
    return error
  }
};
 
export { handler };
